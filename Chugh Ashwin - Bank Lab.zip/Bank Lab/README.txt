As far as I see, every requirement was met for this lab.
Requirements met
-bank class exactly as specified on the class diagram 
-3 customers with their proper pins, names, and balances for the challenge which was achieved through an array 
-text to display name and balance
-one textfield input for withdraw/deposits
    -balance gets updated with each deposit/withdrawal
-Update name button that changes name under user information panel
-can not withdraw to a negative balance
-sign out button that sets access to false and renders every button non-functional until a pin is entered in again
-background image of a vector art ATM machine imported through a "universal" method that does not require a path on a local machine