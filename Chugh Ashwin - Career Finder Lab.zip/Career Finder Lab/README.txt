This is my completed career finder lab. Run through the traditional way -- "javac *.java && java Runner". Pretty standard approach to complete the challenge. Same loop method as
the formulas lab except now the function that is looped is different. Aside from that, everything seems standard and equal to the guidelines specified on the google doc. The career
class is structured exactly as speciified.

Checklist
12 career choices -- completed
challenge -- completed
3 profiles -- completed
take inputs from users and display the results -- completed
